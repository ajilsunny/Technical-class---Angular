import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { SampleService } from '../sample.service';
import { student } from '../student';
@Component({
  selector: 'app-profie',
  templateUrl: './profie.component.html',
  styleUrls: ['./profie.component.css']
})
export class ProfieComponent implements OnInit {
  student =new student();
error:any;
sucess:any;
  constructor(private obj:SampleService) { }

  ngOnInit() {
  }

  registration(f: NgForm){
    this.obj.store(this.student).subscribe(
      data=>{
        this.sucess="Registration ok";
        f.reset();
      },(err)=>{this.error= err;}
    )

  }

}
